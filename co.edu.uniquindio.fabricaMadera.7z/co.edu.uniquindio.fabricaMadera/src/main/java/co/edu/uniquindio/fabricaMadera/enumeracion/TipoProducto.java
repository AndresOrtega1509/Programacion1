package co.edu.uniquindio.fabricaMadera.enumeracion;

public enum TipoProducto {
    MUEBLE, PUERTA, MESA, SILLA, VIGA, ESCRITORIO
}
