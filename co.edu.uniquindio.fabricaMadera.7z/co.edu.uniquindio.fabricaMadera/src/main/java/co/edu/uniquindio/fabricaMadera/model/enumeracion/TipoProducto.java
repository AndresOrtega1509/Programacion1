package co.edu.uniquindio.fabricaMadera.model.enumeracion;

public enum TipoProducto {
    MUEBLE, PUERTA, MESA, SILLA, VIGA, ESCRITORIO
}
