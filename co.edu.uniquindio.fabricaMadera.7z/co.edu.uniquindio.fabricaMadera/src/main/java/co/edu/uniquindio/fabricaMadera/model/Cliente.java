package co.edu.uniquindio.fabricaMadera.model;

public class Cliente {

    public Cliente() {
    }
}
