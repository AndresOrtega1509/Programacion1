package co.edu.uniquindio.fabricaMadera.model.enumeracion;

public enum NombreEmpleado {
    CARLOS, RICARDO, MIGUEL, ANDREA, SANDRA
}
