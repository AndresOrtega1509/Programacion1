package co.edu.uniquindio.fabricaMadera.model.enumeracion;

public enum ApellidoEmpleado {
    RODRIGUEZ, MENDOZA, LONDOÑO, CARDONA, PEREZ
}
