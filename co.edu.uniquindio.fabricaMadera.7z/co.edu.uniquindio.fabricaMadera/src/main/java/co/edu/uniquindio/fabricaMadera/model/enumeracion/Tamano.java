package co.edu.uniquindio.fabricaMadera.model.enumeracion;

public enum Tamano {
    GRANDE, MEDIANO, PEQUEÑO
}
